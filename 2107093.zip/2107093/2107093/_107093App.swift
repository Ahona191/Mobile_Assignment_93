//
//  _107093App.swift
//  2107093
//
//  Created by macos on 23/2/26.
//

import SwiftUI
import Firebase
@main
struct _107093App: App {
    init() {
                FirebaseApp.configure()
                
                
            }
    var body: some Scene {
            WindowGroup {
                ContentView()
            }
        }
    
}
